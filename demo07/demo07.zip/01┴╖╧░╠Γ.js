//1.判断服务器上面有没有upload目录。如果没有创建这个目录，如果有的话不做操作。   （图片上传）




//2. wwwroot文件夹下面有images css js 以及index.html , 找出 wwwroot目录下面的所有的目录，然后放在一个数组中