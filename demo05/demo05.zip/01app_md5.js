/*

1、https://www.npmjs.com/package/md5

2、npm install md5 --save

3、var md5=require('md5');

4、md5('123456');


*/ 

var md5=require('md5');

//实现md5加密的功能
console.log(md5('123456'));